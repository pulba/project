---
layout: '../demo/wedding-11.astro'
slug: 'posts/wedding-11'
title: 'Tema 11'
desc: 'Tema 11'
price: 'Rp 75.000'
unprice: 'Rp 150.000'
number: 11
countdown: "June 5, 2025 15:37:25"
img:
  url: '/assets/demo-11.webp'
  alt: jejak bahagia

#colors
bgfs: 'bg-purple-200'
bgsc: 'bg-purple-600'
bgth: 'bg-purple-900'

txfs: 'text-purple-200'
txsc: 'text-purple-600'
txth: 'text-purple-900'
txfr: 'text-yellow-500'

bdr: 'border-purple-900'
from: 'before:from-purple-900'
before: 'before:bg-black'

# Img header
cover: '/assets/img-5.webp'
imgsc: '/assets/img-6.webp'
bg: '/assets/dekor-24.webp'

#dekor
dekorfs: '/assets/dekor13.webp'
dekorsc: '/assets/dekor14.webp'
# Img kedua mempelai
pm1: '/assets/img-27.webp'
pm2: '/assets/img-26.webp'

# Img Our moment
imgstory1: '/assets/img-5.webp'
imgstory2: '/assets/img-6.webp'
imgstory3: '/assets/img-7.webp'
imgstory4: '/assets/img-8.webp'
imgstory5: '/assets/img-9.webp'
imgstory6: '/assets/img-10.webp'
imgstory7: '/assets/img-30.webp'
imgstory8: '/assets/img-30.webp'

# data mempelai
male: "Remeo"
fullmale: "Remeo Alexa"
female: "Juliet"
fullfemale: "Juliet Kapolo"
music: john-legend-all-of-me

childmale: "Putra kelima dari Pasangan"
childfemale: "Putri Pertama dari Pasangan"
parentmale: "Joko & Siti"
parentfemale: "Bambang & Mulyani"
instagrammale: "instagram"
instagramfemale: "instagram"
facebookmale: "facebook"
facebookfemale: "facebook"
citymale: "Palembang"
cityfemale: "Makkasar"

# name bank
logoml: /assets/gopay.png
bankml: "BRI"
namebankml: "Remeo Alexa"
numberbankml: "123456789"
logofml: /assets/bca.png
bankfml: "BCA"
namebankfml: "Juliet Kapolo"
numberbankfml: "123456789"

# waktu & tempat acara
datefs: Jumat, 05 Januari 2030
datesc: Jumat, 05 Januari 2030
dateth: Jumat, 05 Januari 2030
timefs: 08:00 - 09:00 WIB
timesc: 10:00 - 11:00 WIB
timeth: 13:00 - end WIB
locationfs: BMasjid Kampus UGM
locationsc: Masjid Kampus UGM
locationth: Masjid Kampus UGM
addressfs: Jl. Raya Janti Jl. Wonocatur, Wonocatur, Banguntapan, Kec. Banguntapan, Kabupaten Bantul, Daerah Istimewa Yogyakarta 55198
addresssc: Jl. Raya Janti Jl. Wonocatur, Wonocatur, Banguntapan, Kec. Banguntapan, Kabupaten Bantul, Daerah Istimewa Yogyakarta 55198
addressth: Jl. Raya Janti Jl. Wonocatur, Wonocatur, Banguntapan, Kec. Banguntapan, Kabupaten Bantul, Daerah Istimewa Yogyakarta 55198
mapsfs: https://maps.app.goo.gl/fpXEChVvcrKveA468 
mapssc: https://maps.app.goo.gl/fpXEChVvcrKveA468
mapsth: https://maps.app.goo.gl/fpXEChVvcrKveA468
linkmaps: https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3953.144855136041!2d110.3807054!3d-7.7744606!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a59b4fe07a7f9%3A0x2f7c4fd3d72616bb!2sJl.%20Prof.%20DR.%20Drs%20Notonagoro%2C%20Karang%20Malang%2C%20Caturtunggal%2C%20Kec.%20Depok%2C%20Kabupaten%20Sleman%2C%20Daerah%20Istimewa%20Yogyakarta%2055281!5e0!3m2!1sid!2sid!4v1717643524613!5m2!1sid!2sid

# story love
storyfs: "Di sebuah kafe yang nyaman di tengah kota, dua orang asing, Yanti dan Yanto, tak sengaja bertemu. Yanto, seorang fotografer yang sedang mencari inspirasi untuk proyek terbarunya, sedangkan Yanti, seorang penulis lepas yang sedang mencatat ide-ide baru untuk novel romantisnya, tak menyadari bahwa matanya sedang bertatapan dengan seorang pria tampan di sisi lain kafe."
storysc: "Beberapa bulan kemudian, Romeo memutuskan bahwa dia tidak ingin kehilangan Juliet dari hidupnya. Dengan hati yang penuh harap, dia menyiapkan proposal yang tak terlupakan. Di bawah langit malam yang cerah, di taman yang dihiasi dengan ratusan lentera, Romeo berlutut di hadapan Juliet."
storyth: "Dari pertemuan tak terduga di kafe hingga momen indah pertunangan mereka di taman yang dipenuhi lentera, cerita cinta Juliet dan Romeo adalah bukti bahwa takdir bisa membawa dua hati yang saling mencari dan membuat mereka bersatu dalam cinta yang abadi."

quote: "Maha Suci Allah yang telah menciptakan manusia dengan berpasang-pasangan. Dengan memohon Rahmat dan Ridho Allah SWT, kami bermaksud mengundang Saudara/i dalam acara resepsi pernikahan kami."
---
