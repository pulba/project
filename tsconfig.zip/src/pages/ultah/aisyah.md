---
layout: "../demobd/ultah-1.astro"
title: "Birthday"
slug: "ultah/aisyah"
type: "Birthday"
ultah: 6
desc: "Tema Ulang Tahun"
price: 'Rp 75.000'
unprice: 'Rp 150.000'
img:
  url: "/assets/dekor47.webp"

# Colors
bgfs: "bg-blue-100"
bgsc: "bg-pink-300"
bgth: "bg-blue-900"

txfs: "text-white"
txsc: "text-pink-600"
txth: "text-blue-900"

bdr: "border-pink-100"
from: "from-pink-100"
before: "before:bg-pink-100"

# Img Header
cover: "/assets/dekor45.webp"
imgsc: "/assets/img-25.webp"
bg: "/assets/dekor-24.webp"

# Dekor
dekorfs: "/assets/dekor44.webp"
dekorsc: "/assets/dekor46.webp"
dekorth: "/assets/dekor47.webp"

# Data 
name: "Aisyah"
fullname: "Aisyah Salsabila"
date: "Saturday, August 31 2024"
birth: "25 Agustus 2007"
music: "kezia"
countdown: "Aug 25, 2024 17:00:00"

child: "Putri dari Pasangan"
parent: "Beny Irawan & Elnny Kusuma"
city: "Jakarta Pusat"

# Bank
logoml: "/assets/bca.png"
bankml: "BCA"
namebankml: "Beny Irawan"
numberbankml: "5270325663"

logofml: "/assets/gopay.png"
bankfml: "Gopay"
namebankfml: "Elnny Kusuma"
numberbankfml: "081281938558"

# Waktu & Tempat Acara
time: "17:00 - Selesai WIB"
address: "Hotel Luminor Pecenongan"
mapsfs: "https://maps.app.goo.gl/fi6GRArAS7ppuHkR8"
linkmaps: "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15866.989655995547!2d106.8260866!3d-6.1645715!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5da5ecda557%3A0x231ad86e140e0b89!2sHotel%20Luminor%20Pecenongan!5e0!3m2!1sid!2sid!4v1718076708034!5m2!1sid!2sid"

quote: "Dengan segala kerendahan hati, kami sangat berbahagia bisa membagi saat-saat penting ini kepada Bapak/Ibu/Saudara/i. Besar harapan kami atas kehadiran serta iringan doa dan restunya agar pernikahan yang akan digelar bisa berjalan sebagaimana mestinya. Terimakasih."
---
